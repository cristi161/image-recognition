from django.shortcuts import render
from django.http import  HttpResponse
from django.shortcuts import redirect
from .models import *
from django.views.generic import ListView, CreateView
from django.urls import reverse_lazy

# Create your views here.
def pagina(request):
    return  render(request, 'charecog.html', {})



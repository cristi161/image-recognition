from django.apps import AppConfig


class SiteWebConfig(AppConfig):
    name = 'site_web'
